import { useState } from 'react'
import { DORK_PRESETS, SOCIAL_PLATFORMS } from '../data/config'

const MONO = "'JetBrains Mono', monospace"
const BEBAS = "'Bebas Neue', sans-serif"

// ─── DORK BUILDER ───────────────────────────────────────────────────────────
export function DorkBuilder({ onSave }) {
  const [f, setF] = useState({ site:'', inurl:'', intitle:'', intext:'', ft:'', extra:'', free:'' })
  const [copied, setCopied] = useState(false)
  const set = (k, v) => setF(p => ({...p,[k]:v}))

  const query = [
    f.site && `site:${f.site}`,
    f.inurl && `inurl:${f.inurl}`,
    f.intitle && `intitle:"${f.intitle}"`,
    f.intext && `intext:"${f.intext}"`,
    f.ft && `filetype:${f.ft}`,
    f.extra, f.free
  ].filter(Boolean).join(' ')

  const search = (e) => {
    if (!query) return
    const u = {google:`https://www.google.com/search?q=${encodeURIComponent(query)}`,ddg:`https://duckduckgo.com/?q=${encodeURIComponent(query)}`,bing:`https://www.bing.com/search?q=${encodeURIComponent(query)}`}
    window.open(u[e],'_blank')
  }

  const inpStyle = { background:'#000', border:'1px solid #2a2a2a', color:'#fff', padding:'12px 14px', fontFamily:MONO, fontSize:13, borderRadius:4, outline:'none', width:'100%' }

  return (
    <div style={{animation:'fadeUp 0.25s ease'}}>
      <div style={{borderBottom:'2px solid #1d4ed8',paddingBottom:14,marginBottom:24}}>
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:4}}>
          <span style={{fontFamily:MONO,fontSize:18,color:'#1d4ed8'}}>⚡</span>
          <h2 style={{fontFamily:BEBAS,fontSize:28,color:'#fff',letterSpacing:3,fontWeight:400}}>GOOGLE DORK BUILDER</h2>
        </div>
        <div style={{fontFamily:MONO,fontSize:11,color:'#555',letterSpacing:1}}>CONSTRUCCIÓN DE BÚSQUEDAS AVANZADAS CON OPERADORES ESPECIALIZADOS</div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,marginBottom:16}}>
        {[['SITE: (DOMINIO)','site','ejemplo.com'],['INURL: (TEXTO EN URL)','inurl','admin'],['INTITLE: (TÍTULO)','intitle','index of'],['INTEXT: (CONTENIDO)','intext','password']].map(([l,k,p])=>(
          <div key={k}>
            <label style={{display:'block',fontFamily:MONO,fontSize:9,color:'#1d4ed8',letterSpacing:1.5,marginBottom:6}}>{l}</label>
            <input style={inpStyle} value={f[k]} placeholder={p} onChange={e=>set(k,e.target.value)} onFocus={e=>e.target.style.borderColor='#1d4ed8'} onBlur={e=>e.target.style.borderColor='#2a2a2a'} />
          </div>
        ))}
        <div>
          <label style={{display:'block',fontFamily:MONO,fontSize:9,color:'#1d4ed8',letterSpacing:1.5,marginBottom:6}}>FILETYPE:</label>
          <select style={{...inpStyle}} value={f.ft} onChange={e=>set('ft',e.target.value)}>
            <option value="">— TODOS —</option>
            {['pdf','xls','xlsx','doc','txt','sql','env','log','xml','json','php','bak'].map(x=><option key={x} value={x}>{x.toUpperCase()}</option>)}
          </select>
        </div>
        <div>
          <label style={{display:'block',fontFamily:MONO,fontSize:9,color:'#1d4ed8',letterSpacing:1.5,marginBottom:6}}>OPERADOR EXTRA:</label>
          <select style={{...inpStyle}} value={f.extra} onChange={e=>set('extra',e.target.value)}>
            <option value="">— NINGUNO —</option>
            <option value='"Index of /"'>Index of /</option>
            <option value='"phpMyAdmin"'>phpMyAdmin expuesto</option>
            <option value='"wp-config"'>WordPress config</option>
            <option value='"passwd"'>Archivos passwd</option>
            <option value='inurl:"/.git"'>Git expuesto</option>
          </select>
        </div>
        <div style={{gridColumn:'1/-1'}}>
          <label style={{display:'block',fontFamily:MONO,fontSize:9,color:'#1d4ed8',letterSpacing:1.5,marginBottom:6}}>TÉRMINOS LIBRES</label>
          <input style={inpStyle} value={f.free} placeholder="palabras clave adicionales..." onChange={e=>set('free',e.target.value)} onFocus={e=>e.target.style.borderColor='#1d4ed8'} onBlur={e=>e.target.style.borderColor='#2a2a2a'} />
        </div>
      </div>

      <div style={{background:'#0d0d0d',border:'1px solid #2a2a2a',borderRadius:6,padding:16,marginBottom:16}}>
        <div style={{fontFamily:MONO,fontSize:9,color:'#555',letterSpacing:2,marginBottom:8}}>QUERY GENERADA</div>
        <div style={{background:'#000',border:`1px solid ${query?'#2a5500':'#1a1a1a'}`,borderRadius:4,padding:'12px 14px',fontFamily:MONO,fontSize:14,color:query?'#22c55e':'#333',minHeight:44,wordBreak:'break-all',position:'relative'}}>
          {query||'// Completá los campos para construir el dork...'}
          {query && <button onClick={()=>{navigator.clipboard.writeText(query);setCopied(true);setTimeout(()=>setCopied(false),1500)}} style={{position:'absolute',top:8,right:8,background:'#111',border:'1px solid #2a2a2a',borderRadius:3,color:copied?'#22c55e':'#555',padding:'3px 8px',fontSize:9,cursor:'pointer',fontFamily:MONO}}>{copied?'✓ COPIADO':'COPIAR'}</button>}
        </div>
      </div>

      <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:20}}>
        {[['→ GOOGLE','google','#1d4ed8','#000'],['→ DUCKDUCKGO','ddg','#de5833','#fff'],['→ BING','bing','#1d4ed8','#fff']].map(([l,e,bg,c])=>(
          <button key={e} onClick={()=>search(e)} style={{padding:'10px 20px',background:bg,border:'none',borderRadius:4,color:c,fontFamily:BEBAS,fontSize:16,letterSpacing:2,cursor:'pointer'}}>{l}</button>
        ))}
        {query && <button onClick={()=>onSave(`DORK: ${query}`)} style={{padding:'10px 20px',background:'transparent',border:'1px solid #2a2a2a',borderRadius:4,color:'#555',fontFamily:MONO,fontSize:11,cursor:'pointer'}}>+ GUARDAR</button>}
      </div>

      <div>
        <div style={{fontFamily:MONO,fontSize:9,color:'#444',letterSpacing:2,marginBottom:10}}>PRESETS RÁPIDOS</div>
        <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
          {DORK_PRESETS.map(p=>(
            <button key={p.label} onClick={()=>setF({...f,free:p.query})}
              style={{padding:'6px 14px',background:'#0d0d0d',border:'1px solid #2a2a2a',borderRadius:20,color:'#888',fontSize:12,cursor:'pointer',transition:'all 0.15s'}}
              onMouseEnter={e=>{e.target.style.borderColor='#1d4ed8';e.target.style.color='#1d4ed8'}}
              onMouseLeave={e=>{e.target.style.borderColor='#2a2a2a';e.target.style.color='#888'}}>
              {p.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── SOCIAL PANEL ────────────────────────────────────────────────────────────
export function SocialPanel({ onSave }) {
  const [plat, setPlat] = useState('Facebook')
  const [val, setVal] = useState('')

  const p = SOCIAL_PLATFORMS[plat]

  return (
    <div style={{animation:'fadeUp 0.25s ease'}}>
      <div style={{borderBottom:'2px solid #1d4ed8',paddingBottom:14,marginBottom:24}}>
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:4}}>
          <span style={{fontFamily:MONO,fontSize:18,color:'#1d4ed8'}}>◑</span>
          <h2 style={{fontFamily:BEBAS,fontSize:28,color:'#fff',letterSpacing:3,fontWeight:400}}>REDES SOCIALES OSINT</h2>
        </div>
        <div style={{fontFamily:MONO,fontSize:11,color:'#555',letterSpacing:1}}>INVESTIGACIÓN ESPECIALIZADA POR PLATAFORMA</div>
      </div>

      <div style={{display:'flex',gap:4,flexWrap:'wrap',marginBottom:20}}>
        {Object.keys(SOCIAL_PLATFORMS).map(k=>(
          <button key={k} onClick={()=>setPlat(k)}
            style={{padding:'8px 16px',background:plat===k?'#111':'transparent',border:`1px solid ${plat===k?p.color:'#2a2a2a'}`,borderRadius:4,color:plat===k?'#fff':'#555',fontSize:13,fontWeight:plat===k?700:400,cursor:'pointer',transition:'all 0.15s'}}>
            {k}
          </button>
        ))}
      </div>

      <div style={{background:'#0d0d0d',border:`1px solid ${p.color}44`,borderRadius:6,padding:16,marginBottom:20}}>
        <label style={{display:'block',fontFamily:MONO,fontSize:10,color:p.color,letterSpacing:1.5,marginBottom:8}}>TÉRMINO DE BÚSQUEDA — {plat.toUpperCase()}</label>
        <div style={{display:'flex',gap:10}}>
          <input value={val} onChange={e=>setVal(e.target.value)} onKeyDown={e=>e.key==='Enter'&&null}
            placeholder="username, email o término..."
            style={{flex:1,background:'#000',border:'1px solid #2a2a2a',color:'#fff',padding:'12px 16px',fontFamily:MONO,fontSize:14,borderRadius:4,outline:'none'}}
            onFocus={e=>e.target.style.borderColor=p.color} onBlur={e=>e.target.style.borderColor='#2a2a2a'} />
          <button style={{padding:'12px 24px',background:p.color,border:'none',borderRadius:4,color:'#000',fontFamily:BEBAS,fontSize:16,letterSpacing:2,cursor:'pointer'}}>BUSCAR</button>
        </div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))',gap:10}}>
        {p.tools.map((t,i)=>(
          <div key={i} style={{background:'#0d0d0d',border:'1px solid #2a2a2a',borderRadius:6,padding:16,transition:'border-color 0.2s'}}
            onMouseEnter={e=>e.currentTarget.style.borderColor='#1d4ed8'}
            onMouseLeave={e=>e.currentTarget.style.borderColor='#2a2a2a'}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:6}}>
              <span style={{fontFamily:MONO,fontSize:13,fontWeight:700,color:'#fff'}}>{t.name}</span>
              <div style={{width:6,height:6,borderRadius:'50%',background:p.color}} />
            </div>
            <div style={{fontSize:12,color:'#555',marginBottom:12,lineHeight:1.5}}>{t.desc}</div>
            <div style={{display:'flex',gap:8}}>
              <a href={t.url(val||'')} target="_blank" rel="noreferrer"
                style={{flex:1,padding:'8px',background:'transparent',border:`1px solid ${p.color}44`,borderRadius:4,color:p.color,fontFamily:MONO,fontSize:11,fontWeight:700,textDecoration:'none',display:'flex',alignItems:'center',justifyContent:'center',gap:4}}>
                → ABRIR
              </a>
              <button onClick={()=>onSave(`[${plat}] ${t.name}: ${t.url(val||'')}`)}
                style={{padding:'8px 12px',background:'transparent',border:'1px solid #2a2a2a',borderRadius:4,color:'#444',fontFamily:MONO,fontSize:10,cursor:'pointer'}}>
                + GUARDAR
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── PDF MODAL ───────────────────────────────────────────────────────────────
export function PDFModal({ isOpen, onClose, saved }) {
  const [author, setAuthor] = useState('')
  const [title, setTitle] = useState('')
  const [notes, setNotes] = useState('')

  if (!isOpen) return null

  const generate = () => {
    const { jsPDF } = window.jspdf
    const doc = new jsPDF({ orientation:'portrait',unit:'mm',format:'a4' })
    const W=210, H=297
    const now = new Date().toLocaleString('es-AR')
    const auth = author||'Investigador Ciberbrigada'
    const tit = title||'Informe de Investigación OSINT'

    doc.setFillColor(0,0,0); doc.rect(0,0,W,H,'F')
    doc.setFillColor(13,13,13); doc.rect(0,0,W,55,'F')
    doc.setFillColor(249,115,22); doc.rect(0,0,5,55,'F')
    doc.setFillColor(249,115,22); doc.rect(0,55,W,2,'F')

    doc.setTextColor(249,115,22); doc.setFontSize(24); doc.setFont('helvetica','bold')
    doc.text('CIBERBRIGADA', 14,20)
    doc.setTextColor(200,200,200); doc.setFontSize(9); doc.setFont('helvetica','normal')
    doc.text('PLATAFORMA DE CIBERINTELIGENCIA Y OSINT', 14,29)
    doc.setTextColor(80,80,80); doc.setFontSize(8)
    doc.text(`CLASIFICACIÓN: USO OFICIAL  |  FECHA: ${now}`, 14,37)
    doc.text(`ELABORADO POR: ${auth.toUpperCase()}`, 14,44)

    doc.setTextColor(249,115,22); doc.setFontSize(60); doc.setGState(new doc.GState({opacity:0.04}))
    doc.text('CIBERBRIGADA', W/2, H/2, {align:'center',angle:45})
    doc.setGState(new doc.GState({opacity:1}))

    doc.setTextColor(255,255,255); doc.setFontSize(16); doc.setFont('helvetica','bold')
    doc.text(tit.toUpperCase(), 14, 68)
    doc.setDrawColor(40,40,40); doc.setLineWidth(0.3); doc.line(14,73,W-14,73)

    let y=82
    if(notes){
      doc.setTextColor(249,115,22); doc.setFontSize(8); doc.setFont('helvetica','bold')
      doc.text('RESUMEN EJECUTIVO', 14, y); y+=6
      doc.setTextColor(200,200,200); doc.setFontSize(8); doc.setFont('helvetica','normal')
      const ls=doc.splitTextToSize(notes,W-28); doc.text(ls,14,y); y+=ls.length*4.5+10
      doc.setDrawColor(30,30,30); doc.line(14,y-4,W-14,y-4)
    }

    doc.setTextColor(249,115,22); doc.setFontSize(8); doc.setFont('helvetica','bold')
    doc.text(`REGISTROS DE INVESTIGACIÓN — ${saved.length} ENTRADAS`, 14, y); y+=8

    saved.forEach(r=>{
      if(y>H-25){
        doc.addPage(); doc.setFillColor(0,0,0); doc.rect(0,0,W,H,'F')
        doc.setTextColor(249,115,22); doc.setFontSize(60); doc.setGState(new doc.GState({opacity:0.04}))
        doc.text('CIBERBRIGADA',W/2,H/2,{align:'center',angle:45}); doc.setGState(new doc.GState({opacity:1}))
        y=20
      }
      doc.setFillColor(13,13,13); doc.roundedRect(12,y-3,W-24,r.text.split('\n').length>1?r.text.split('\n').length*5+10:16,1,1,'F')
      doc.setTextColor(80,80,80); doc.setFontSize(7); doc.setFont('helvetica','normal')
      doc.text(`[${r.time}]`,16,y+2)
      doc.setTextColor(200,200,200); doc.setFontSize(8)
      const lines=r.text.split('\n')
      lines.forEach((l,i)=>{ if(y+8+(i*4.5)<H-15) doc.text(l.substring(0,90),16,y+8+(i*4.5)) })
      y+=lines.length*4.5+14
    })

    const pages=doc.getNumberOfPages()
    for(let i=1;i<=pages;i++){
      doc.setPage(i)
      doc.setFillColor(13,13,13); doc.rect(0,H-10,W,10,'F')
      doc.setFillColor(249,115,22); doc.rect(0,H-10,W,1,'F')
      doc.setTextColor(60,60,60); doc.setFontSize(7)
      doc.text('CIBERBRIGADA | PLATAFORMA OSINT | DOCUMENTO OFICIAL',14,H-4)
      doc.text(`${i} / ${pages}`,W-14,H-4,{align:'right'})
    }
    doc.save(`CB_${tit.replace(/\s+/g,'_').substring(0,25)}_${Date.now()}.pdf`)
    onClose()
  }

  const inp = {width:'100%',background:'#000',border:'1px solid #2a2a2a',color:'#fff',padding:'12px 14px',fontFamily:MONO,fontSize:13,borderRadius:4,outline:'none'}

  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.9)',zIndex:2000,display:'flex',alignItems:'center',justifyContent:'center'}} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:'#0d0d0d',border:'1px solid #2a2a2a',borderRadius:6,width:520,maxWidth:'92vw',overflow:'hidden'}}>
        <div style={{background:'#111',padding:'16px 20px',borderBottom:'1px solid #1a1a1a',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div>
            <div style={{fontFamily:BEBAS,fontSize:22,color:'#fff',letterSpacing:3}}>EXPORTAR INFORME PDF</div>
            <div style={{fontFamily:MONO,fontSize:10,color:'#444',marginTop:2}}>{saved.length} REGISTROS INCLUIDOS</div>
          </div>
          <button onClick={onClose} style={{background:'none',border:'none',color:'#444',fontSize:18,cursor:'pointer'}}>✕</button>
        </div>
        <div style={{padding:22}}>
          {[['INVESTIGADOR / AUTOR',author,setAuthor,'Ej: Investigador OSINT'],['TÍTULO DEL INFORME',title,setTitle,'Ej: Caso #001 — Objetivo X']].map(([l,v,sv,p])=>(
            <div key={l} style={{marginBottom:14}}>
              <label style={{display:'block',fontFamily:MONO,fontSize:9,color:'#1d4ed8',letterSpacing:1.5,marginBottom:6}}>{l}</label>
              <input style={inp} value={v} placeholder={p} onChange={e=>sv(e.target.value)} onFocus={e=>e.target.style.borderColor='#1d4ed8'} onBlur={e=>e.target.style.borderColor='#2a2a2a'} />
            </div>
          ))}
          <div style={{marginBottom:14}}>
            <label style={{display:'block',fontFamily:MONO,fontSize:9,color:'#1d4ed8',letterSpacing:1.5,marginBottom:6}}>RESUMEN EJECUTIVO</label>
            <textarea style={{...inp,resize:'vertical',minHeight:80}} value={notes} placeholder="Hallazgos, observaciones y conclusiones de la investigación..." onChange={e=>setNotes(e.target.value)} onFocus={e=>e.target.style.borderColor='#1d4ed8'} onBlur={e=>e.target.style.borderColor='#2a2a2a'} />
          </div>
        </div>
        <div style={{padding:'14px 22px',borderTop:'1px solid #1a1a1a',display:'flex',justifyContent:'flex-end',gap:10}}>
          <button onClick={onClose} style={{padding:'10px 20px',background:'transparent',border:'1px solid #2a2a2a',borderRadius:4,color:'#555',fontSize:13,cursor:'pointer',fontFamily:MONO}}>CANCELAR</button>
          <button onClick={generate} style={{padding:'10px 28px',background:'#1d4ed8',border:'none',borderRadius:4,color:'#000',fontFamily:BEBAS,fontSize:18,letterSpacing:2,cursor:'pointer'}}>GENERAR PDF</button>
        </div>
      </div>
    </div>
  )
}
