import { useState } from 'react'

const STATUS_COLORS = {
  green: { bg: 'rgba(34,197,94,0.12)', border: '#16a34a', text: '#22c55e' },
  red: { bg: 'rgba(239,68,68,0.12)', border: '#dc2626', text: '#ef4444' },
  orange: { bg: 'rgba(29,78,216,0.12)', border: '#1e40af', text: '#1d4ed8' },
  yellow: { bg: 'rgba(234,179,8,0.12)', border: '#ca8a04', text: '#eab308' },
}

export default function ResultCard({ api, data, onSave, query }) {
  const [copied, setCopied] = useState(false)
  const [expanded, setExpanded] = useState(true)

  if (!data) return null

  const rendered = api.render ? api.render(data) : null

  const handleSave = () => {
    if (!rendered) return
    const lines = [`[${api.name}] Consulta: ${query}`]
    lines.push(`Estado: ${rendered.status}`)
    rendered.fields?.forEach(f => lines.push(`${f.label}: ${f.value}`))
    if (rendered.list?.length) {
      lines.push(`${rendered.listLabel || 'Resultados'}:`)
      rendered.list.forEach(item => lines.push(`  - ${item}`))
    }
    onSave(lines.join('\n'))
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const statusCol = STATUS_COLORS[rendered?.statusColor || 'green']

  return (
    <div style={{ background: '#0d0d0d', border: '1px solid #2a2a2a', borderRadius: 6, overflow: 'hidden', marginBottom: 12 }}>

      {/* Card header */}
      <div style={{ background: '#111', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid #1a1a1a', cursor: 'pointer' }} onClick={() => setExpanded(e => !e)}>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: rendered ? statusCol.text : '#555', flexShrink: 0 }} />
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700, color: '#fff', letterSpacing: 1 }}>{api.name}</span>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, padding: '2px 7px', background: 'rgba(29,78,216,0.1)', border: '1px solid rgba(29,78,216,0.3)', borderRadius: 3, color: '#1d4ed8', letterSpacing: 1 }}>{api.badge}</span>
          </div>
          <div style={{ fontSize: 11, color: '#aaaaaa', marginTop: 2 }}>{api.desc}</div>
        </div>
        {rendered && (
          <div style={{ padding: '4px 12px', background: statusCol.bg, border: `1px solid ${statusCol.border}`, borderRadius: 4, fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: statusCol.text, fontWeight: 700, letterSpacing: 1, whiteSpace: 'nowrap' }}>
            {rendered.status}
          </div>
        )}
        {data.error && (
          <div style={{ padding: '4px 12px', background: 'rgba(239,68,68,0.1)', border: '1px solid #dc2626', borderRadius: 4, fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#ef4444', letterSpacing: 1 }}>
            ERROR
          </div>
        )}
        <span style={{ color: '#999999', fontSize: 12 }}>{expanded ? '▲' : '▼'}</span>
      </div>

      {/* Card body */}
      {expanded && (
        <div style={{ padding: 16 }}>
          {data.error && (
            <div style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 4, padding: '10px 14px', marginBottom: 12 }}>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#ef4444' }}>ERROR: {data.error}</div>
              {data.fallback && (
                <a href={data.fallback} target="_blank" rel="noreferrer" style={{ display: 'inline-block', marginTop: 8, fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#1d4ed8', textDecoration: 'none' }}>
                  → Abrir manualmente: {data.fallback}
                </a>
              )}
              {data.command && (
                <div style={{ marginTop: 8, fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#bbbbbb' }}>
                  Comando: <span style={{ color: '#22c55e' }}>{data.command}</span>
                </div>
              )}
            </div>
          )}

          {rendered && (
            <>
              {/* Fields grid */}
              {rendered.fields && rendered.fields.length > 0 && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 8, marginBottom: 14 }}>
                  {rendered.fields.map((f, i) => (
                    <div key={i} style={{ background: '#111', border: '1px solid #1a1a1a', borderRadius: 4, padding: '10px 14px' }}>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 9, color: '#1d4ed8', letterSpacing: 1.5, marginBottom: 4 }}>{f.label}</div>
                      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: '#fff', wordBreak: 'break-all' }}>{f.value}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* GPS / Map link */}
              {rendered.mapLink && (
                <a href={rendered.mapLink} target="_blank" rel="noreferrer"
                  style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '8px 16px', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.4)', borderRadius: 4, color: '#ef4444', fontFamily: "'JetBrains Mono', monospace", fontSize: 12, fontWeight: 700, textDecoration: 'none', marginBottom: 14 }}>
                  ⚠ {rendered.mapLabel || 'VER EN MAPA'}
                </a>
              )}

              {/* List results */}
              {rendered.list && rendered.list.length > 0 && (
                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#1d4ed8', letterSpacing: 1.5, marginBottom: 8 }}>{rendered.listLabel || 'RESULTADOS'} ({rendered.list.length})</div>
                  <div style={{ background: '#0a0a0a', border: '1px solid #1a1a1a', borderRadius: 4, padding: '10px 14px', maxHeight: 240, overflowY: 'auto' }}>
                    {rendered.list.map((item, i) => (
                      <div key={i} style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#ccc', padding: '4px 0', borderBottom: i < rendered.list.length - 1 ? '1px solid #1a1a1a' : 'none', wordBreak: 'break-all' }}>
                        <span style={{ color: '#22c55e', marginRight: 8 }}>+</span>{item}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Raw output */}
              {rendered.raw && (
                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#aaaaaa', letterSpacing: 1.5, marginBottom: 6 }}>OUTPUT RAW</div>
                  <pre style={{ background: '#0a0a0a', border: '1px solid #1a1a1a', borderRadius: 4, padding: '10px 14px', fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#bbbbbb', overflow: 'auto', maxHeight: 160, whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
                    {rendered.raw}
                  </pre>
                </div>
              )}

              {/* Save button */}
              <button onClick={handleSave}
                style={{ padding: '8px 20px', background: copied ? 'rgba(34,197,94,0.1)' : 'transparent', border: `1px solid ${copied ? '#16a34a' : '#2a2a2a'}`, borderRadius: 4, color: copied ? '#22c55e' : '#666', fontFamily: "'JetBrains Mono', monospace", fontSize: 11, fontWeight: 700, cursor: 'pointer', letterSpacing: 1, transition: 'all 0.2s' }}>
                {copied ? '✓ GUARDADO' : '+ GUARDAR EN INFORME'}
              </button>
            </>
          )}
        </div>
      )}
    </div>
  )
}
