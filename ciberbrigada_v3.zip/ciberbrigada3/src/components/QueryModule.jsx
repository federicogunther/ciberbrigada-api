import { useState } from 'react'
import ResultCard from './ResultCard'
import { API_BASE } from '../data/config'

export default function QueryModule({ mod, onSave }) {
  const [value, setValue] = useState('')
  const [loading, setLoading] = useState({})
  const [results, setResults] = useState({})
  const [submitted, setSubmitted] = useState('')
  const [queried, setQueried] = useState(false)

  const runAll = async (val) => {
    if (!val.trim()) return
    const v = val.trim()
    setSubmitted(v)
    setQueried(true)
    setResults({})

    const loadMap = {}
    mod.apis.forEach(api => { loadMap[api.id] = true })
    setLoading(loadMap)

    await Promise.allSettled(
      mod.apis.map(async (api) => {
        try {
          const url = `${API_BASE}${api.endpoint(v)}`
          const res = await fetch(url, { signal: AbortSignal.timeout(90000) })
          const data = await res.json()
          setResults(prev => ({ ...prev, [api.id]: data }))
        } catch (err) {
          setResults(prev => ({ ...prev, [api.id]: { error: err.message || 'Error de conexión con el backend' } }))
        } finally {
          setLoading(prev => ({ ...prev, [api.id]: false }))
        }
      })
    )
  }

  const handleSubmit = () => runAll(value)
  const handleKey = (e) => { if (e.key === 'Enter') handleSubmit() }

  const anyLoading = Object.values(loading).some(Boolean)

  return (
    <div style={{ animation: 'fadeUp 0.25s ease' }}>

      {/* Module header */}
      <div style={{ borderBottom: '2px solid #1d4ed8', paddingBottom: 14, marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 18, color: '#1d4ed8' }}>{mod.icon}</span>
          <h2 style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 28, color: '#fff', letterSpacing: 3, fontWeight: 400 }}>{mod.label}</h2>
        </div>
        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#aaaaaa', letterSpacing: 1 }}>
          {mod.apis.length > 0 ? `${mod.apis.length} API${mod.apis.length > 1 ? 'S' : ''} DIRECTA${mod.apis.length > 1 ? 'S' : ''} DISPONIBLE${mod.apis.length > 1 ? 'S' : ''}` : 'FUENTES EXTERNAS DISPONIBLES'}
          {mod.links?.length > 0 && ` · ${mod.links.length} FUENTES ADICIONALES`}
        </div>
      </div>

      {/* Search input */}
      <div style={{ background: '#0d0d0d', border: '1px solid #2a2a2a', borderRadius: 6, padding: 20, marginBottom: 24 }}>
        <label style={{ display: 'block', fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#1d4ed8', letterSpacing: 2, marginBottom: 10 }}>
          {mod.inputLabel}
        </label>
        <div style={{ display: 'flex', gap: 10 }}>
          <input
            type={mod.inputType || 'text'}
            value={value}
            onChange={e => setValue(e.target.value)}
            onKeyDown={handleKey}
            placeholder={mod.placeholder}
            style={{ flex: 1, background: '#000', border: '1px solid #3a3a3a', color: '#fff', padding: '14px 18px', fontFamily: "'JetBrains Mono', monospace", fontSize: 15, borderRadius: 4, outline: 'none', transition: 'border-color 0.2s' }}
            onFocus={e => e.target.style.borderColor = '#1d4ed8'}
            onBlur={e => e.target.style.borderColor = '#3a3a3a'}
          />
          <button onClick={handleSubmit} disabled={anyLoading || !value.trim()}
            style={{ padding: '14px 32px', background: anyLoading ? '#2a1500' : '#1d4ed8', border: 'none', borderRadius: 4, color: '#000', fontFamily: "'Bebas Neue', sans-serif", fontSize: 18, letterSpacing: 2, cursor: anyLoading ? 'wait' : 'pointer', display: 'flex', alignItems: 'center', gap: 10, transition: 'background 0.2s', whiteSpace: 'nowrap', minWidth: 160, justifyContent: 'center' }}>
            {anyLoading ? (
              <>
                <span style={{ width: 16, height: 16, border: '2px solid rgba(29,78,216,0.3)', borderTop: '2px solid #1d4ed8', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block' }} />
                BUSCANDO
              </>
            ) : '→ CONSULTAR'}
          </button>
        </div>
        {mod.apis.length > 0 && (
          <div style={{ marginTop: 10, fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#999999' }}>
            ENTER para consultar · Los resultados aparecen en tiempo real
          </div>
        )}
      </div>

      {/* API Results */}
      {queried && mod.apis.length > 0 && (
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#1d4ed8', letterSpacing: 2, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#1d4ed8', display: 'inline-block' }} />
            RESULTADOS API — CONSULTA: "{submitted}"
          </div>
          {mod.apis.map(api => (
            <div key={api.id}>
              {loading[api.id] ? (
                <div style={{ background: '#0d0d0d', border: '1px solid #2a2a2a', borderRadius: 6, padding: '14px 16px', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span style={{ width: 14, height: 14, border: '2px solid #2a2a2a', borderTop: '2px solid #1d4ed8', borderRadius: '50%', animation: 'spin 0.8s linear infinite', display: 'inline-block', flexShrink: 0 }} />
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#aaaaaa' }}>
                    {api.name} — Procesando consulta...
                  </span>
                </div>
              ) : results[api.id] ? (
                <ResultCard api={api} data={results[api.id]} onSave={onSave} query={submitted} />
              ) : null}
            </div>
          ))}
        </div>
      )}

      {/* Alternative links */}
      {mod.links && mod.links.length > 0 && (
        <div>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#999999', letterSpacing: 2, marginBottom: 14, paddingTop: queried ? 12 : 0, borderTop: queried ? '1px solid #1a1a1a' : 'none' }}>
            {mod.apis.length > 0 ? 'FUENTES ALTERNATIVAS' : 'FUENTES DISPONIBLES'} — ABRE EN NUEVA PESTAÑA
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 10 }}>
            {mod.links.map((link, i) => (
              <a key={i} href={link.url(submitted || '')} target="_blank" rel="noreferrer"
                style={{ background: '#0d0d0d', border: '1px solid #2a2a2a', borderRadius: 6, padding: '14px 18px', textDecoration: 'none', display: 'block', transition: 'border-color 0.2s' }}
                onMouseEnter={e => e.currentTarget.style.borderColor = '#1d4ed8'}
                onMouseLeave={e => e.currentTarget.style.borderColor = '#2a2a2a'}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700, color: '#fff' }}>{link.name}</span>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#1d4ed8' }}>→</span>
                </div>
                <div style={{ fontSize: 12, color: '#aaaaaa' }}>{link.desc}</div>
              </a>
            ))}
          </div>
        </div>
      )}

      {!queried && mod.apis.length === 0 && (
        <div style={{ background: '#0d0d0d', border: '1px solid #1a1a1a', borderRadius: 6, padding: '32px', textAlign: 'center' }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#888888' }}>
            // INGRESÁ UN DATO PARA GENERAR LOS LINKS DE CONSULTA
          </div>
        </div>
      )}
    </div>
  )
}
