import { useState, useEffect } from 'react'
import { MODULES } from './data/config'
import QueryModule from './components/QueryModule'
import { DorkBuilder, SocialPanel, PDFModal } from './components/Panels'

export default function App() {
  const [active, setActive] = useState('username')
  const [saved, setSaved] = useState([])
  const [pdf, setPdf] = useState(false)
  const [time, setTime] = useState('')
  const [mobile, setMobile] = useState(false)
  const [sideOpen, setSideOpen] = useState(false)

  useEffect(() => {
    const t = setInterval(() => setTime(new Date().toLocaleString('es-AR')), 1000)
    const check = () => setMobile(window.innerWidth < 900)
    check()
    window.addEventListener('resize', check)
    return () => { clearInterval(t); window.removeEventListener('resize', check) }
  }, [])

  const saveResult = (text) => {
    setSaved(prev => [{ text, time: new Date().toLocaleString('es-AR') }, ...prev])
  }

  const goTo = (id) => { setActive(id); setSideOpen(false); window.scrollTo(0, 0) }

  const groups = [
    { label: 'CONSULTAS', ids: ['username','email','phone','domain','image'] },
    { label: 'ANÁLISIS', ids: ['dork'] },
    { label: 'FUENTES', ids: ['argentina','social'] },
  ]

  const modMap = Object.fromEntries(MODULES.map(m => [m.id, m]))

  const MONO = "'JetBrains Mono', monospace"
  const BEBAS = "'Bebas Neue', sans-serif"

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', background: '#000' }}>

      {/* TOP HEADER */}
      <header style={{ background: '#000', borderBottom: '1px solid #1a1a1a', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', position: 'sticky', top: 0, zIndex: 100, flexShrink: 0 }}>
        {/* Left: Logo + Name */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          {mobile && (
            <button onClick={() => setSideOpen(o => !o)}
              style={{ background: 'none', border: '1px solid #2a2a2a', color: '#888', padding: '6px 12px', borderRadius: 4, cursor: 'pointer', fontFamily: MONO, fontSize: 14 }}>
              ☰
            </button>
          )}
          <img src="/logos/logo_icon.png" alt="CB" style={{ height: 44, width: 44, objectFit: 'contain', borderRadius: 4, mixBlendMode: 'screen' }} />
          <div>
            <div style={{ fontFamily: BEBAS, fontSize: 22, color: '#fff', letterSpacing: 4, lineHeight: 1 }}>
              CIBER<span style={{ color: '#1d4ed8' }}>BRIGADA</span>
            </div>
            <div style={{ fontFamily: MONO, fontSize: 9, color: '#888888', letterSpacing: 3, textTransform: 'uppercase', marginTop: 1 }}>
              Plataforma OSINT · Ciberinteligencia
            </div>
          </div>
        </div>

        {/* Center: Status bar */}
        {!mobile && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#22c55e', animation: 'pulse 2s infinite' }} />
              <span style={{ fontFamily: MONO, fontSize: 10, color: '#888888', letterSpacing: 1 }}>SISTEMA ACTIVO</span>
            </div>
            <div style={{ width: 1, height: 16, background: '#1a1a1a' }} />
            <span style={{ fontFamily: MONO, fontSize: 10, color: '#888888' }}>{time}</span>
            <div style={{ width: 1, height: 16, background: '#1a1a1a' }} />
            <span style={{ fontFamily: MONO, fontSize: 10, color: '#888888' }}>{saved.length} REGISTROS GUARDADOS</span>
          </div>
        )}

        {/* Right: Actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {saved.length > 0 && (
            <button onClick={() => goTo('saved')}
              style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px', background: 'transparent', border: '1px solid #2a2a2a', borderRadius: 4, color: '#888', fontFamily: MONO, fontSize: 11, cursor: 'pointer', letterSpacing: 1 }}>
              <span style={{ background: '#1d4ed8', color: '#000', borderRadius: '50%', width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700 }}>{saved.length}</span>
              INFORME
            </button>
          )}
          <button onClick={() => setPdf(true)}
            style={{ padding: '7px 18px', background: '#1d4ed8', border: 'none', borderRadius: 4, color: '#000', fontFamily: BEBAS, fontSize: 16, letterSpacing: 2, cursor: 'pointer' }}>
            EXPORTAR PDF
          </button>
        </div>
      </header>

      {/* ORANGE ACCENT LINE */}
      <div style={{ height: 2, background: 'linear-gradient(90deg, #f97316 0%, #1d4ed8 50%, transparent 100%)', flexShrink: 0 }} />

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

        {/* SIDEBAR */}
        {(!mobile || sideOpen) && (
          <aside style={{ width: 240, background: '#050505', borderRight: '1px solid #1a1a1a', flexShrink: 0, overflowY: 'auto', position: mobile ? 'fixed' : 'sticky', top: mobile ? 0 : 66, height: mobile ? '100vh' : 'calc(100vh - 66px)', zIndex: mobile ? 200 : 1 }}>
            {mobile && (
              <div style={{ padding: '14px 18px', borderBottom: '1px solid #1a1a1a', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontFamily: MONO, fontSize: 9, color: '#888888', letterSpacing: 3 }}>NAVEGACIÓN</span>
                <button onClick={() => setSideOpen(false)} style={{ background: 'none', border: 'none', color: '#aaaaaa', cursor: 'pointer', fontSize: 16 }}>✕</button>
              </div>
            )}

            {/* Watermark logo in sidebar bottom */}
            <div style={{ position: 'absolute', bottom: 20, left: '50%', transform: 'translateX(-50%)', opacity: 0.04, pointerEvents: 'none', width: 160 }}>
              <img src="/logos/logo_text.png" alt="" style={{ width: '100%', objectFit: 'contain' }} />
            </div>

            {groups.map(group => (
              <div key={group.label} style={{ borderBottom: '1px solid #0f0f0f', paddingBottom: 4 }}>
                <div style={{ fontFamily: MONO, fontSize: 8, color: '#888888', letterSpacing: 3, padding: '14px 18px 6px', textTransform: 'uppercase' }}>
                  {group.label}
                </div>
                {group.ids.map(id => {
                  const m = modMap[id]
                  if (!m) return null
                  const isActive = active === id
                  return (
                    <button key={id} onClick={() => goTo(id)}
                      style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 18px', width: '100%', textAlign: 'left', background: isActive ? '#0d0d0d' : 'none', borderLeft: `3px solid ${isActive ? '#1d4ed8' : 'transparent'}`, border: 'none', borderRight: 'none', borderTop: 'none', borderBottom: 'none', borderLeftWidth: 3, borderLeftStyle: 'solid', borderLeftColor: isActive ? '#1d4ed8' : 'transparent', color: isActive ? '#fff' : '#555', cursor: 'pointer', transition: 'all 0.15s', fontFamily: "'Inter', sans-serif" }}
                      onMouseEnter={e => { if (!isActive) { e.currentTarget.style.color = '#888'; e.currentTarget.style.background = '#0a0a0a' } }}
                      onMouseLeave={e => { if (!isActive) { e.currentTarget.style.color = '#555'; e.currentTarget.style.background = 'none' } }}>
                      <span style={{ fontFamily: MONO, fontSize: 12, color: isActive ? '#1d4ed8' : '#333', width: 16, textAlign: 'center', flexShrink: 0 }}>{m.icon}</span>
                      <span style={{ fontSize: 13, fontWeight: isActive ? 600 : 400, letterSpacing: 0.3 }}>{m.label}</span>
                    </button>
                  )
                })}
              </div>
            ))}

            {/* Saved / PDF */}
            <div style={{ borderBottom: '1px solid #0f0f0f', paddingBottom: 4 }}>
              <div style={{ fontFamily: MONO, fontSize: 8, color: '#888888', letterSpacing: 3, padding: '14px 18px 6px' }}>SESIÓN</div>
              <button onClick={() => goTo('saved')}
                style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 18px', width: '100%', textAlign: 'left', background: active === 'saved' ? '#0d0d0d' : 'none', border: 'none', borderLeft: `3px solid ${active === 'saved' ? '#1d4ed8' : 'transparent'}`, color: active === 'saved' ? '#fff' : '#555', cursor: 'pointer', fontFamily: "'Inter', sans-serif", fontSize: 13 }}>
                <span style={{ fontFamily: MONO, fontSize: 12, color: active === 'saved' ? '#1d4ed8' : '#333', width: 16, textAlign: 'center' }}>◎</span>
                Registros Guardados
                {saved.length > 0 && <span style={{ marginLeft: 'auto', background: '#1d4ed8', color: '#000', borderRadius: '50%', width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, flexShrink: 0 }}>{saved.length}</span>}
              </button>
              <button onClick={() => setPdf(true)}
                style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '11px 18px', width: '100%', textAlign: 'left', background: 'none', border: 'none', borderLeft: '3px solid transparent', color: '#aaaaaa', cursor: 'pointer', fontFamily: "'Inter', sans-serif", fontSize: 13 }}>
                <span style={{ fontFamily: MONO, fontSize: 12, color: '#888888', width: 16, textAlign: 'center' }}>▤</span>
                Exportar PDF
              </button>
            </div>
          </aside>
        )}

        {mobile && sideOpen && (
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 199 }} onClick={() => setSideOpen(false)} />
        )}

        {/* MAIN CONTENT */}
        <main style={{ flex: 1, overflowY: 'auto', padding: mobile ? '20px 16px' : '32px 36px', position: 'relative' }}>

          {/* Background watermark - large diagonal */}
          <div style={{ position: 'fixed', top: '50%', left: mobile ? '50%' : 'calc(50% + 120px)', transform: 'translate(-50%, -50%) rotate(-30deg)', pointerEvents: 'none', zIndex: 0, opacity: 0.06, userSelect: 'none', width: '90vw' }}>
            <img src="/logos/logo_text.png" alt="" style={{ width: '100%', objectFit: 'contain', filter: 'brightness(2) saturate(0.5)' }} />
          </div>

          <div style={{ position: 'relative', zIndex: 1 }}>

            {/* MODULE PANELS */}
            {MODULES.filter(m => !m.isDork && !m.isSocial).map(mod =>
              active === mod.id && <QueryModule key={mod.id} mod={mod} onSave={saveResult} />
            )}
            {active === 'dork' && <DorkBuilder onSave={saveResult} />}
            {active === 'social' && <SocialPanel onSave={saveResult} />}

            {/* SAVED RESULTS */}
            {active === 'saved' && (
              <div style={{ animation: 'fadeUp 0.25s ease' }}>
                <div style={{ borderBottom: '2px solid #1d4ed8', paddingBottom: 14, marginBottom: 24 }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                        <span style={{ fontFamily: MONO, fontSize: 18, color: '#1d4ed8' }}>◎</span>
                        <h2 style={{ fontFamily: BEBAS, fontSize: 28, color: '#fff', letterSpacing: 3, fontWeight: 400 }}>REGISTROS DE INVESTIGACIÓN</h2>
                      </div>
                      <div style={{ fontFamily: MONO, fontSize: 11, color: '#aaaaaa', letterSpacing: 1 }}>{saved.length} ENTRADAS EN ESTA SESIÓN</div>
                    </div>
                    <div style={{ display: 'flex', gap: 10 }}>
                      <button onClick={() => setPdf(true)} style={{ padding: '10px 24px', background: '#1d4ed8', border: 'none', borderRadius: 4, color: '#000', fontFamily: BEBAS, fontSize: 18, letterSpacing: 2, cursor: 'pointer' }}>EXPORTAR PDF</button>
                      <button onClick={() => setSaved([])} style={{ padding: '10px 20px', background: 'transparent', border: '1px solid #2a2a2a', borderRadius: 4, color: '#aaaaaa', fontFamily: MONO, fontSize: 11, cursor: 'pointer', letterSpacing: 1 }}>LIMPIAR</button>
                    </div>
                  </div>
                </div>

                {saved.length === 0 ? (
                  <div style={{ background: '#0d0d0d', border: '1px solid #1a1a1a', borderRadius: 6, padding: '48px 32px', textAlign: 'center' }}>
                    <div style={{ fontFamily: MONO, fontSize: 13, color: '#222' }}>// SIN REGISTROS GUARDADOS</div>
                    <div style={{ fontFamily: MONO, fontSize: 11, color: '#1a1a1a', marginTop: 8 }}>Usá el botón "+ GUARDAR EN INFORME" en cualquier resultado</div>
                  </div>
                ) : (
                  <div style={{ background: '#0d0d0d', border: '1px solid #1a1a1a', borderRadius: 6, overflow: 'hidden' }}>
                    {saved.map((r, i) => (
                      <div key={i} style={{ padding: '14px 18px', borderBottom: i < saved.length - 1 ? '1px solid #111' : 'none' }}>
                        <div style={{ fontFamily: MONO, fontSize: 9, color: '#888888', marginBottom: 6, letterSpacing: 1 }}>[{r.time}]</div>
                        <pre style={{ fontFamily: MONO, fontSize: 12, color: '#888', whiteSpace: 'pre-wrap', wordBreak: 'break-all', lineHeight: 1.6 }}>{r.text}</pre>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </main>
      </div>

      <PDFModal isOpen={pdf} onClose={() => setPdf(false)} saved={saved} />

      <style>{`
        @keyframes fadeUp { from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);} }
        @keyframes pulse { 0%,100%{opacity:1;}50%{opacity:0.3;} }
        @keyframes spin { from{transform:rotate(0deg);}to{transform:rotate(360deg);} }
        * { -webkit-font-smoothing: antialiased; }
        input::placeholder, textarea::placeholder { color: #333; }
        select option { background: #000; color: #fff; }
      `}</style>
    </div>
  )
}
